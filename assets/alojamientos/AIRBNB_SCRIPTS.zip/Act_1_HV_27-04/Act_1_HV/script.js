let tipoHabitacionSeleccionado = null;
let COLORES_TIPOS_HABITACION = {};
let ciudadSeleccionada = "__ALL__";  // Por defecto, todas
let datosProcesados;
// Constantes y configuración
const MAP_CONFIG = {
  containerId: 'map',
  initialView: [40.71, -73.99], // NYC
  initialZoom: 9,
  tileLayerUrl: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
  tileLayerAttribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  markerDefaults: {
    color: '#444',
    weight: 0.5,
    opacity: 1,
    fillOpacity: 0.6,
    defaultFillColor: '#cccccc'
  },
  radiusDefaults: { min: 3, max: 15 }
};

const RATINGS_CHART_CONFIG = {
  containerSelector: "#chart-container", // Same container as the old bar chart
  svgId: "ratings-roomtype-chart", // Unique ID for the SVG
  tooltipSelector: ".tooltip", // Reuse tooltip class if desired, or define a new one
  margin: { top: 30, right: 30, bottom: 20, left: 100 }, // Margins from the provided snippet
  barHeight: 30, // Height of each bar
  barColor: 'orange', // Color of the bars
  labelColor: 'white', // Color of the text labels on bars
  labelPadding: 5 // Pixels padding from the end of the bar for the label
};

const WORD_CLOUD_CONFIG = {
  containerSelector: '#cloud-container',
  width: 800,
  height: 300,
  topN: 40,
  fontFamily: 'Arial',
  fontSizeScaleFactor: 0.4,
  rotationAngles: [0, 90]
}

const DATA_URL = './Airbnb_data.json'; 
const ROOM_TYPE_COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b'];

// Función para procesar datos de Airbnb
function procesarDatosAirbnb(rawData) {
  // Comproar si los datos son un array no vacío
  const alojamientos = Array.isArray(rawData) ? rawData : [rawData];
  if (!alojamientos || alojamientos.length === 0) {
    console.error("No data found or data is empty.");
    return [];
  }

  const procesado = {
    alojamientos: [],
    tiposHabitaciones: {},
    precios: [],
    conteoServicios: {}
  };

  alojamientos.forEach(prop => {
    // Trabajamos con una copia
    const propiedad = { ...prop };

    // Convertir tipos de datos
    propiedad.latitude = +propiedad.latitude;
    propiedad.longitude = +propiedad.longitude;
    propiedad.price = +propiedad.price;
    propiedad.number_of_reviews = +propiedad.number_of_reviews;
    propiedad.review_scores_rating = +propiedad.review_scores_rating || 0; // Manejar puntuaciones faltantes

    // Procesar tipos de habitación: tipos únicos
    if (propiedad.room_type) {
      procesado.tiposHabitaciones[propiedad.room_type] = procesado.tiposHabitaciones[propiedad.room_type] || null;
    }

    // Procesar precios: todos valores no nulos
    if (!isNaN(propiedad.price)) {
      procesado.precios.push(propiedad.price);
    }

    // Procesar servicios
    let listaServicios = [];
    if (propiedad.amenities && typeof propiedad.amenities === 'string') {
      // Limpiar la cadena de servicios
      listaServicios = propiedad.amenities
        .split(',')
        .map(amenity => amenity.trim().toLowerCase())
        .filter(amenity => amenity !== '');

    } else if (Array.isArray(propiedad.amenities)) {
      // Caso donde ya es un array
      listaServicios = propiedad.amenities
        .map(amenity => String(amenity).trim().toLowerCase())
        .filter(amenity => amenity !== '');
    }

    // Contar servicios
    listaServicios.forEach(amenity => {
      if (amenity) { // Asegurarse de que no esté vacío después del procesamiento
        procesado.conteoServicios[amenity] = (procesado.conteoServicios[amenity] || 0) + 1;
      }
    });

    // Agregar propiedad procesada a la lista
    procesado.alojamientos.push(propiedad);

  });
  console.log("Datos procesados:", procesado);
  return procesado;
}

// Función para inicializar el mapa
function inicializarMapa() {
  const mapa = L.map(MAP_CONFIG.containerId, { preferCanvas: true })
    .setView(MAP_CONFIG.initialView, MAP_CONFIG.initialZoom);
  
  L.tileLayer(MAP_CONFIG.tileLayerUrl, {
    attribution: MAP_CONFIG.tileLayerAttribution
  }).addTo(mapa);

  console.log("Mapa inicializado.");
  return mapa;
}

// Función para agregar marcadores y leyenda al mapa
function agregarElementosMapa(mapa, alojamientos, tiposHabitaciones, precios) {
  // Eliminar leyenda DOM anterior si existe
  const leyendaAnterior = document.getElementById('leyenda-custom');
  if (leyendaAnterior && leyendaAnterior.parentNode) {
    leyendaAnterior.parentNode.removeChild(leyendaAnterior);
  }
  if (!mapa || !alojamientos || !tiposHabitaciones || !precios) {
    console.error("Faltan datos para agregar elementos al mapa.");
    return;
  }

  // Asignar colores a tipos de habitación
  const coloresTipos = COLORES_TIPOS_HABITACION;

  // Calcular escala de precios (Valor por defecto si no hay precio)
  const minPrecio = precios.length > 0 ? Math.min(...precios) : 0;
  const maxPrecio = precios.length > 0 ? Math.max(...precios) : 100;
  const rangoPrecio = maxPrecio - minPrecio;

  // Función para convertir precio a radio
  function precioARadio(precio) {
    const { min: minR, max: maxR } = MAP_CONFIG.radiusDefaults;
    if (isNaN(precio) || rangoPrecio <= 0) return (minR + maxR) / 2;
    const precioNormalizado = Math.max(0, Math.min(1, (precio - minPrecio) / rangoPrecio));
    return precioNormalizado * (maxR - minR) + minR; // Escala lineal de minR a maxR
  }

  // Agregar marcadores al mapa
  alojamientos.forEach(prop => {
    // Comprobar coordenadas válidas
    if (isNaN(prop.latitude) || isNaN(prop.longitude)) {
      console.warn("Saltando propiedad debido a coordenadas inválidas:", prop.name || prop.id);
      return;
    }

    const radio = precioARadio(prop.price);
    const colorRelleno = coloresTipos[prop.room_type] || MAP_CONFIG.markerDefaults.defaultFillColor;

    // Contenido tooltip
    const textoTooltip =
      `<strong>${prop.name || 'N/A'}</strong><br/>` +
      `Barrio: ${prop.neighbourhood || 'N/A'}<br/>` +
      `Precio: $${!isNaN(prop.price) ? prop.price.toFixed(2) : 'N/A'}<br/>` +
      `Reseñas: ${prop.number_of_reviews || 0}<br/>` +
      `Puntuación: ${prop.review_scores_rating ? prop.review_scores_rating + '%' : 'N/A'}`;

    // Crear y añadir el marcador
    L.circleMarker([prop.latitude, prop.longitude], {
      radius: radio,
      fillColor: colorRelleno,
      color: MAP_CONFIG.markerDefaults.color,
      weight: MAP_CONFIG.markerDefaults.weight,
      opacity: MAP_CONFIG.markerDefaults.opacity,
      fillOpacity: MAP_CONFIG.markerDefaults.fillOpacity
    })
    .addTo(mapa)
    .bindTooltip(textoTooltip, { sticky: true }); // Mostrar al pasar el mouse
  });


  let leyendaActual = null;

// Crear nueva leyenda
  const leyenda = L.control({ position: 'bottomright' });
  leyenda.onAdd = () => {
    const div = L.DomUtil.create('div', 'legend');
    div.id = 'leyenda-custom'; // <- ID único para encontrarla y eliminarla luego
    let leyendaHtml = '<strong>Tipos de habitación</strong><br/>';

    // Mostrar solo el tipo seleccionado si hay uno activo, si no, todos
    const tiposParaMostrar = tipoHabitacionSeleccionado 
    ? [tipoHabitacionSeleccionado] 
    : Object.keys(tiposHabitaciones);
    
    tiposParaMostrar.forEach(tipo => {
      const color = coloresTipos[tipo] || '#999';
      leyendaHtml += `
        <span class="leyenda-color" style="background:${color}"></span>
        <span style="color:${color}">${tipo}</span><br/>
      `;
    });

    leyendaHtml += '<br><strong>Precio (Radio)</strong><br/>';
    leyendaHtml += `Min: $${minPrecio.toFixed(0)} <span style="font-size: ${MAP_CONFIG.radiusDefaults.min*2}px;">●</span> | `;
    leyendaHtml += `Max: $${maxPrecio.toFixed(0)} <span style="font-size: ${MAP_CONFIG.radiusDefaults.max*2}px;">●</span>`;

    div.innerHTML = leyendaHtml;
    return div;
  };

  leyenda.addTo(mapa);

  // Guardar referencia a la leyenda actual
  leyendaActual = leyenda;
  console.log("Elementos del mapa agregados.");
}

// Función para crear el gráfico de puntuaciones por tipo de habitación
function crearGraficoPuntuaciones(alojamientos, datosProcesados) {
  const { containerSelector, svgId, tooltipSelector, margin, barHeight, barColor, labelColor, labelPadding } = RATINGS_CHART_CONFIG;

  // Preparar datos
  const alojamientosValidos = alojamientos.filter(prop => prop.review_scores_rating !== null && typeof prop.review_scores_rating === 'number');
  if (alojamientosValidos.length === 0) {
    d3.select(containerSelector).append("p").text("No hay datos de puntuaciones disponibles para mostrar.");
    return;
  }

  // Agrupar por tipo de habitación y calcular media de puntuaciones
  const mediaPuntuaciones = d3.rollups(
    alojamientosValidos,
    v => d3.mean(v, d => d.review_scores_rating),
    d => d.room_type
  );

  // Formatear y escalar
  const mediaPuntuacionesFormateadas = mediaPuntuaciones.map(([tipo, puntuacion]) => ({
    room_type: tipo || "Desconocido",
    averageRating: +(puntuacion / 10).toFixed(2)
  }));

  // Ordenar por puntuación
  mediaPuntuacionesFormateadas.sort((a, b) => b.averageRating - a.averageRating);
  if (mediaPuntuacionesFormateadas.length === 0) {
    d3.select(containerSelector).append("p").text("No hay datos de puntuaciones disponibles para mostrar.");
    return;
  }

  // Establecer dimensiones
  const numBars = mediaPuntuacionesFormateadas.length;
  const height = numBars * barHeight + margin.top + margin.bottom;
  const containerNode = d3.select(containerSelector).node();
  const containerWidth = containerNode ? containerNode.getBoundingClientRect().width : 700;
  const width = containerWidth;

  // Crear SVG
  const container = d3.select(containerSelector);
  container.select("#" + svgId).remove();

  const svg = container.append("svg")
    .attr("id", svgId)
    .attr("width", width)
    .attr("height", height)
    .attr("viewBox", [0, 0, width, height])
    .attr("style", "width: 100%; height: 100%")
  
  // Añadir listener para "clic fuera de barras" que restablece las visualizaciones
  svg.on("click", function(event) {
    const isBarClick = event.target.tagName.toLowerCase() === 'rect';
  
  // Clic fuera de barra y hay filtro activo
  if (!isBarClick && tipoHabitacionSeleccionado !== null) {
    tipoHabitacionSeleccionado = null;

    d3.selectAll("rect").classed("selected-bar", false);

    // Filtrar por ciudad si aplica
    const alojamientosFiltrados = ciudadSeleccionada === "__ALL__"
      ? datosProcesados.alojamientos
      : datosProcesados.alojamientos.filter(d => d.city === ciudadSeleccionada);

    const tiposHabitacionesFiltrados = {};
    alojamientosFiltrados.forEach(d => {
      tiposHabitacionesFiltrados[d.room_type] = null;
    });
    const preciosFiltrados = alojamientosFiltrados.map(d => d.price);

    // Recontar servicios
    const conteoFiltrado = {};
    alojamientosFiltrados.forEach(prop => {
      let servicios = [];
      if (typeof prop.amenities === 'string') {
        servicios = prop.amenities.split(',').map(s => s.trim().toLowerCase());
      } else if (Array.isArray(prop.amenities)) {
        servicios = prop.amenities.map(s => String(s).trim().toLowerCase());
      }
      servicios.forEach(s => {
        if (s) conteoFiltrado[s] = (conteoFiltrado[s] || 0) + 1;
      });
  });

  // Aplicar visualizaciones con datos filtrados por ciudad (o todos si "__ALL__")
  agregarElementosMapa(mapa, alojamientosFiltrados, tiposHabitacionesFiltrados, preciosFiltrados);
  crearNubePalabras(conteoFiltrado);
}
  });
  
  // Crear escalas
  const xMax = d3.max(mediaPuntuacionesFormateadas, d => d.averageRating);
  const xScale = d3.scaleLinear()
    .domain([0, xMax > 0 ? xMax : 100])
    .range([margin.left, width - margin.right]);
    // .padding(0.1); 
  const yScale = d3.scaleBand()
    .domain(mediaPuntuacionesFormateadas.map(d => d.room_type))
    .range([margin.top, height - margin.bottom])
    .padding(0.1); // Espaciado entre barras
  
  // Dibujar barras
  // Dibujar barras
  svg.append("g")
  .selectAll("rect")
  .data(mediaPuntuacionesFormateadas)
  .join("rect")
  .attr("fill", d => COLORES_TIPOS_HABITACION[d.room_type] || '#ccc') // ← Asigna color según tipo
  .attr("x", xScale(0))
  .attr("y", d => yScale(d.room_type))
  .attr("width", 0)
  .attr("height", yScale.bandwidth())
  .on("click", function(event, d) {
    // Eliminar selección previa
    d3.selectAll("rect").classed("selected-bar", false);
  
    // Añadir clase de selección a la barra clicada
    d3.select(this).classed("selected-bar", true);
  
    // Aplicar filtro
    filtrarPorTipoHabitacion(d.room_type);
  })
  .transition()
  .duration(750)
  .attr("width", d => xScale(d.averageRating) - xScale(0));
  
    // Función para manejar clic en barra del gráfico
    function filtrarPorTipoHabitacion(tipoSeleccionado) {
      const alojamientosFiltrados = alojamientos.filter(d => d.room_type === tipoSeleccionado);
    
      tipoHabitacionSeleccionado = tipoSeleccionado;

      // Limpiar mapa
      mapa.eachLayer(layer => {
        if (layer instanceof L.CircleMarker) mapa.removeLayer(layer);
      });
    
      // Actualizar elementos del mapa y nube de palabras
      const preciosFiltrados = alojamientosFiltrados.map(d => d.price);
      agregarElementosMapa(mapa, alojamientosFiltrados, { [tipoSeleccionado]: null }, preciosFiltrados);
    
      // Recontar servicios solo de alojamientos filtrados
      const conteoFiltrado = {};
      alojamientosFiltrados.forEach(prop => {
        let servicios = [];
        if (typeof prop.amenities === 'string') {
          servicios = prop.amenities.split(',').map(s => s.trim().toLowerCase());
        } else if (Array.isArray(prop.amenities)) {
          servicios = prop.amenities.map(s => String(s).trim().toLowerCase());
        }
        servicios.forEach(s => {
          if (s) conteoFiltrado[s] = (conteoFiltrado[s] || 0) + 1;
        });
      });
      crearNubePalabras(conteoFiltrado);
    }

  // Dibujar etiquetas
  svg.append("g")
    .attr("fill", labelColor)
    .attr("text-anchor", "end")
    .style("font-size", "10px")
    .style("font-family", "sans-serif")
    .selectAll("text")
    .data(mediaPuntuacionesFormateadas)
    .join("text")
    .attr("x", d => xScale(d.averageRating) - labelPadding)
    .attr("y", d => yScale(d.room_type) + yScale.bandwidth() / 2)
    .attr("dy", "0.35em")
    .text(d => d.averageRating.toFixed(2)) // Formato de dos decimales
    .attr("opacity", 0) // Inicialmente oculto
  
    // Añadir transición de entrada
    .transition()
    .delay(750) 
    .duration(500)
    .attr("opacity", 1); // Mostrar al final de la animación de las barras
  
  // Dibujar ejes
  svg.append("g")
    .attr("class", "x-axis")
    .attr("transform", `translate(0,${margin.top})`)
    .call(d3.axisTop(xScale).ticks(width / 80).tickFormat(d => d.toFixed(2))) // Formato de dos decimales
    .call(g => g.select(".domain").remove());  // Eliminar línea del eje
  
  svg.append("g")
    .attr("class", "y-axis")
    .attr("transform", `translate(${margin.left},0)`)
    .call(d3.axisLeft(yScale).tickSizeOuter(0));
  
  svg.selectAll(".axis path, .axis line")
    .attr("stroke", "#ccc"); // Color de los ejes
  svg.selectAll(".axis text")
    .attr("fill", "#555"); // Color del texto de los ejes
  
  console.log("Gráfico de puntuaciones creado.");
}

// Función para crear la nube de palabras
function crearNubePalabras(conteoServicios) {
  const { containerSelector, width, height, topN, padding, fontFamily, fontSizeScaleFactor, rotationAngles } = WORD_CLOUD_CONFIG;

  // Preparar datos
  const datosNube = Object.entries(conteoServicios)
    .map(([texto, conteo]) => ({ text: texto, size: conteo }))
    .sort((a, b) => d3.descending(a.size, b.size)) // Ordenar por tamaño
    .slice(0, topN); // Top N servicios
  
  if (datosNube.length === 0) {
    d3.select(containerSelector).append("p").text("No hay datos de servicios disponibles para mostrar.");
    return;
  }

  // Limpiar contenedor antes de dibujar nueva nube
  d3.select(containerSelector).selectAll("svg").remove();

  // Calcular rangos de frecuencia
  const maxSize = d3.max(datosNube, d => d.size);
  const minSize = d3.min(datosNube, d => d.size);

  // Escalar el tamaño de fuente con base en las dimensiones disponibles
  const maxFontSize = Math.min(width, height) * 0.20;  // Máximo 20% de la dimensión menor
  const minFontSize = Math.max(10, maxFontSize * 0.4); // Al menos 40% del máximo o 10px

  const escalaFuente = d3.scaleSqrt()
    .domain([minSize, maxSize])
    .range([minFontSize, maxFontSize]);

  // Configurar nube de palabras
  const layout = d3.layout.cloud()
    .size([width, height])
    .words(datosNube)
    .padding(padding)
    .rotate(() => rotationAngles[Math.floor(Math.random() * rotationAngles.length)]) // Rotación aleatoria
    .font(fontFamily)
    .fontSize(d => escalaFuente(d.size)) // Escala de tamaño
    .on("end", dibujarNube); // Función de dibujo al finalizar
  
  layout.start(); // Iniciar el layout

  // Función para dibujar la nube de palabras
  function dibujarNube(words) {
    // Escala de color
    const escalaColor = d3.scaleOrdinal(d3.schemeCategory10);

    // Crear contenedor SVG
    const svg = d3.select(containerSelector).append("svg")
      .attr("width", width)
      .attr("height", height)
      .append("g")
      .attr("transform", `translate(${width / 2}, ${height / 2})`);
    
    // Dibujar palabras
    svg.selectAll("text")
      .data(words)
      .enter().append("text")
      .style("font-size", d => `${d.size}px`)
      .style("font-family", fontFamily)
      .style("fill", (d, i) => escalaColor(i)) // Color aleatorio
      .attr("text-anchor", "middle")
      .attr("transform", d => `translate(${d.x},${d.y}) rotate(${d.rotate})`)
      .text(d => d.text)
      
      // Animación de entrada
      .on("mouseover", function (event, d) {
        const tooltip = d3.select(".tooltip");
        tooltip.transition().duration(200).style("opacity", .9);
        tooltip.html(`<strong>${d.text}</strong><br/>Aparece en ${d.size} alojamientos`)
          .style("left", (event.pageX + 10) + "px")
          .style("top", (event.pageY - 28) + "px");
      })
      .on("mouseout", () => {
        const tooltip = d3.select(".tooltip");
        tooltip.transition().duration(500).style("opacity", 0);
      }
    );
  }

  console.log("Nube de palabras creada.");
}

function crearFiltroCiudades(alojamientos) {
  const selector = d3.select("#city-filter");
  const ciudadesUnicas = Array.from(new Set(alojamientos
    .map(d => d.city)
    .filter(c => typeof c === 'string' && c.trim() !== '')))
    .sort();

  // Añadir opciones
  selector.selectAll("option.city-option")
    .data(ciudadesUnicas)
    .enter()
    .append("option")
    .attr("class", "city-option")
    .attr("value", d => d)
    .text(d => d);

  selector.on("change", function () {
    ciudadSeleccionada = this.value;
    
    // Filtrar alojamientos según ciudad
    const alojamientosFiltrados = ciudadSeleccionada === "__ALL__"
      ? datosProcesados.alojamientos
      : datosProcesados.alojamientos.filter(d => d.city === ciudadSeleccionada);
    
    // Si hay alojamientos en la ciudad, centramos el mapa
  if (alojamientosFiltrados.length > 0) {
    const latitudes = alojamientosFiltrados.map(d => d.latitude).filter(lat => !isNaN(lat));
    const longitudes = alojamientosFiltrados.map(d => d.longitude).filter(lon => !isNaN(lon));

    const avgLat = d3.mean(latitudes);
    const avgLon = d3.mean(longitudes);

    if (!isNaN(avgLat) && !isNaN(avgLon)) {
      mapa.setView([avgLat, avgLon], 12); // Zoom más cercano
    }
  }
    
    // Recalcular tipos de habitaciones y precios
    const tiposHabitacionesFiltrados = {};
    alojamientosFiltrados.forEach(d => {
      tiposHabitacionesFiltrados[d.room_type] = null;
    });
    const preciosFiltrados = alojamientosFiltrados.map(d => d.price);
    
    // Recontar servicios para la nube
    const conteoFiltrado = {};
    alojamientosFiltrados.forEach(prop => {
      let servicios = [];
      if (typeof prop.amenities === 'string') {
        servicios = prop.amenities.split(',').map(s => s.trim().toLowerCase());
      } else if (Array.isArray(prop.amenities)) {
        servicios = prop.amenities.map(s => String(s).trim().toLowerCase());
      }
      servicios.forEach(s => {
        if (s) conteoFiltrado[s] = (conteoFiltrado[s] || 0) + 1;
      });
    });
    
    // Reiniciar selección de tipo de habitación si usas otro filtro
    tipoHabitacionSeleccionado = null;
    
    // 🔁 Aplicar las tres visualizaciones
    agregarElementosMapa(mapa, alojamientosFiltrados, tiposHabitacionesFiltrados, preciosFiltrados);
    crearGraficoPuntuaciones(alojamientosFiltrados, {
      alojamientos: alojamientosFiltrados,
      tiposHabitaciones: tiposHabitacionesFiltrados,
      precios: preciosFiltrados
    });
    crearNubePalabras(conteoFiltrado);
  });
}

// Lógica principal
let mapa = null;
function main() {
  // 1. Inicializar mapa
  mapa = inicializarMapa();

  // 2. Cargar datos
  d3.json(DATA_URL).then(datos => {
    console.log("Datos cargados:", datos);

    // 3. Procesar datos
    datosProcesados = procesarDatosAirbnb(datos);

    // Crear filtro de ciudades
    crearFiltroCiudades(datosProcesados.alojamientos);

    // 3.1 Asignar colores fijos a cada tipo de habitación (solo una vez)
    Object.keys(datosProcesados.tiposHabitaciones).forEach((tipo, i) => {
    COLORES_TIPOS_HABITACION[tipo] = ROOM_TYPE_COLORS[i % ROOM_TYPE_COLORS.length];
    });

    if (!datosProcesados) {
      console.error("Error procesando datos.");
      d3.select("body").insert("p", ":first-child")
        .text("Error procesando datos.")
        .style("color", "red")
        .style("font-weight", "bold")
        .style("padding", "10px")
        .style("background-color", "#ffe0e0")
      return;
    }

    // 4. Agregar elementos al mapa
    agregarElementosMapa(mapa, datosProcesados.alojamientos, datosProcesados.tiposHabitaciones, datosProcesados.precios);

    // 5. Crear gráfico de barras
    crearGraficoPuntuaciones(datosProcesados.alojamientos, datosProcesados);

    // 6. Crear nube de palabras
    crearNubePalabras(datosProcesados.conteoServicios);
  })
}
main();